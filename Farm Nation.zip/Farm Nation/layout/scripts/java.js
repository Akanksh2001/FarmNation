var buttons = document.querySelectorAll(".btn");
for(var i=0; i<buttons.length;i++)
{
    buttons[i].addEventListener("click",function(){
        if(confirm("Confirmation of purchase "))
        alert(this.parentElement.parentElement.childNodes[1].textContent);
        else
        alert("cancelled");
    });
}