var totalPrice=0;
var totalItems=0;
var taxAmount=0;
var totalAmount=0;

var inputs=document.querySelectorAll("input[type=number]");
var cartButton=document.querySelector("#add");
var resetButton=document.querySelector("#reset");
var selectedItems=document.querySelector("#total-number-value");
var printPrice=document.querySelector("#total-price-value");
var taxPrint=document.querySelector("#tax-value");
var amountPrint = document.querySelector("#bill-value");
var confirmButton=document.querySelector("#confirm");


cartButton.addEventListener("click",function(){
    document.querySelector("#seatValue").value = "" ;
    document.querySelector(".eatery__confirmation").classList.add("off");
    document.querySelector(".confirm_statement").classList.add("off");
    calculateBill();
    if(totalAmount > 0)
    {
        document.querySelector(".eatery__confirmation").classList.remove("off");
    }
    else
    {
        document.querySelector(".eatery__confirmation").classList.add("off");
        document.querySelector(".confirm_statement").classList.add("off");
        alert("Your cart is empty.");
    }
});

resetButton.addEventListener("click",function(){
    reset();
});

confirmButton.addEventListener("click",function(){
    if(document.querySelector("#seatValue").value != "" )
    {
        document.querySelector("#confirmAmount").textContent=totalAmount;
        document.querySelector(".confirm_statement").classList.remove("off");
    }
    else{
        document.querySelector(".confirm_statement").classList.add("off");
        alert("Enter your ticket number.");
    }
});


function reset()
{
    for(var i=0;i<inputs.length;i++)
    {
        inputs[i].value=0;
    }
    totalPrice=0;
    totalItems=0;
    taxAmount=0;
    totalAmount=0;
    displayBill();
    document.querySelector(".eatery__confirmation").classList.add("off");
    document.querySelector(".confirm_statement").classList.add("off");
    document.querySelector("#seatValue").value = ""; 
}

function calculateBill()
{
    totalPrice=0;
    totalItems=0;
    for(var i=0;i<inputs.length;i++)
    {
        if(parseInt(inputs[i].value) !== 0)
        {
            totalItems=totalItems + parseInt(inputs[i].value);
            calculatePrice(inputs[i]);
        }
    }
    calculateTax();
    calculateAmount();
    displayBill();
}

function displayBill()
{
    selectedItems.textContent=totalItems;
    printPrice.textContent=totalPrice;
    taxPrint.textContent=taxAmount;
    amountPrint.textContent=totalAmount;
}

function calculatePrice(a)
{
    totalPrice = totalPrice + parseInt(a.parentElement.childNodes[1].textContent) * parseInt(a.value);
    totalPrice = parseFloat(totalPrice);
}

function calculateTax()
{
    taxAmount = 0.18 * totalPrice;
    taxAmount = parseFloat(taxAmount.toFixed(2));
}

function calculateAmount()
{
    totalAmount = totalPrice + taxAmount;
}
